/*
Copyright 2021 The cert-manager Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllers

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	"k8s.io/apimachinery/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	ctrlutil "sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"
	"sigs.k8s.io/controller-runtime/pkg/log"

	pawapi "github.com/cert-manager/sample-external-issuer/api/v1alpha1"
	"github.com/go-logr/logr"
	apiutil "github.com/jetstack/cert-manager/pkg/api/util"
	cmapi "github.com/jetstack/cert-manager/pkg/apis/certmanager/v1"
	cmmeta "github.com/jetstack/cert-manager/pkg/apis/meta/v1"
	core "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/tools/record"
	"k8s.io/utils/clock"
)

const (
	levelDebug                   = 1
	OrderStatusNew               = "NEW"
	OrderStatusCaAPIRequestError = "CAAPIERROR"
	OrderStatusFailed            = "FAILED"
	OrderStatusRequested         = "REQUESTED"
	OrderStatusCaAPIQuereyError  = "REQUESTED_CAAPIERROR"
	OrderStatusSigningPending    = "REQUESTED_PENDING"
	OrderStatusDone              = "DONE"
	OrderStatusSkip              = "SKIP"
)

// CA Service
type CAService interface {
	// request the CSR to be signed. Return the request-id, and error or nil and if the request should be retried in case of error
	requestCertificateSigning(logger logr.Logger, cr *cmapi.CertificateRequest, c *cmapi.Certificate) (int, error, bool)

	// get the signed certificate. Return the certificate, ca and error or nil and if the request should be retried in case of error
	getSigningRecord(logger logr.Logger, requestId int) ([]byte, []byte, error, bool)

	deleteSigningRecord(logger logr.Logger, requestId int) error
}

// CertificateRequestReconciler reconciles a CertificateRequest object
type CertificateRequestReconciler struct {
	client.Client
	Scheme   *runtime.Scheme
	Recorder record.EventRecorder
	Clock    clock.Clock
	CAService
}

// Annotation for generating RBAC role for writing Events
// +kubebuilder:rbac:groups="",resources=events,verbs=create;patch
//+kubebuilder:rbac:groups=pickleappware-issuer.pickleappware.com,resources=certificaterequests,verbs=get;list;watch;update;delete
//+kubebuilder:rbac:groups=pickleappware-issuer.pickleappware.com,resources=certificaterequests/status,verbs=get;update;patch
//+kubebuilder:rbac:groups=pickleappware-issuer.pickleappware.com,resources=certificaterequests/finalizers,verbs=update

// Reconcile is part of the main kubernetes reconciliation loop which aims to
// move the current state of the cluster closer to the desired state.
// TODO(user): Modify the Reconcile function to compare the state specified by
// the CertificateRequest object against the actual cluster state, and then
// perform operations to make the cluster state reflect the state specified by
// the user.
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.8.3/pkg/reconcile
func (r *CertificateRequestReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	logger := log.FromContext(ctx)
	dbg := logger.V(levelDebug)

	requestIdAnnotationKey := fmt.Sprintf("%s/request-id", pawapi.GroupVersion.Group)
	certificateRequestFinalizerName := fmt.Sprintf("%s/finalizer", pawapi.GroupVersion.Group)

	// Fetch the CertificateRequest resource being reconciled.
	// Just ignore the request if the certificate request has been deleted.
	cr := new(cmapi.CertificateRequest)
	if err := r.Client.Get(ctx, req.NamespacedName, cr); err != nil {
		if apierrors.IsNotFound(err) {
			return ctrl.Result{}, nil
		}

		logger.Error(err, "PAWCA failed to retrieve CertificateRequest resource")
		return ctrl.Result{}, err
	}

	// Check the CertificateRequest's issuerRef and if it does not match the api
	// group name, log a message at a debug level and stop processing.
	if cr.Spec.IssuerRef.Group != "" && cr.Spec.IssuerRef.Group != pawapi.GroupVersion.Group {
		dbg.Info("PAWCA resource does not specify an issuerRef group name that we are responsible for", "group", cr.Spec.IssuerRef.Group) //nolint:gomnd // TODO: fix when refactoring the logger
		return ctrl.Result{}, nil
	}

	// get request ID
	requestId := -1
	if tmpValue, ok := cr.ObjectMeta.Annotations[requestIdAnnotationKey]; ok {
		requestId, _ = strconv.Atoi(tmpValue)
	}

	// examine DeletionTimestamp to determine if object is under deletion
	if cr.ObjectMeta.DeletionTimestamp.IsZero() {
		// The object is not being deleted, so if it does not have our finalizer,
		// then lets add the finalizer and update the object. This is equivalent
		// registering our finalizer.
		if !containsString(cr.GetFinalizers(), certificateRequestFinalizerName) {
			ctrlutil.AddFinalizer(cr, certificateRequestFinalizerName)
			if err := r.Update(ctx, cr); err != nil {
				return ctrl.Result{}, err
			}
		}
	} else {
		// The object is being deleted
		if containsString(cr.GetFinalizers(), certificateRequestFinalizerName) {
			// our finalizer is present, so lets handle any external dependency
			if err := r.CAService.deleteSigningRecord(logger, requestId); err != nil {
				// if fail to delete the external dependency here, return with error
				// so that it can be retried
				return ctrl.Result{}, err
			}

			// remove our finalizer from the list and update it.
			ctrlutil.RemoveFinalizer(cr, certificateRequestFinalizerName)
			if err := r.Update(ctx, cr); err != nil {
				return ctrl.Result{}, err
			}
		}

		// Stop reconciliation as the item is being deleted
		return ctrl.Result{}, nil
	}

	// check if the request should be processed
	shouldProcess, err := r.requestShouldBeProcessed(ctx, logger, cr)
	if err != nil || !shouldProcess {
		return ctrl.Result{}, err
	}

	dbg.Info("PAWCA --------------------------------------------------------")
	dbg.Info(fmt.Sprintf("PAWCA start processing Certificate Request %s/%s", req.Name, req.Namespace))

	// Fetch the Issuer resource
	issNamespaceName := types.NamespacedName{
		Namespace: req.Namespace,
		Name:      cr.Spec.IssuerRef.Name,
	}
	if cr.Spec.IssuerRef.Kind == "ClusterIssuer" {
		clusterIssuer := new(pawapi.ClusterIssuer)
		if err = r.Client.Get(ctx, issNamespaceName, clusterIssuer); err != nil {
			logger.Error(err, "PAWCA failed to retrieve Issuer resource", "namespace", req.Namespace, "name", cr.Spec.IssuerRef.Name)
			_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonPending, "Failed to retrieve Issuer resource %s: %v", issNamespaceName, err)
			return ctrl.Result{}, err
		}
	} else {
		issuer := new(pawapi.Issuer)
		if err = r.Client.Get(ctx, issNamespaceName, issuer); err != nil {
			logger.Error(err, "PAWCA failed to retrieve Issuer resource", "namespace", req.Namespace, "name", cr.Spec.IssuerRef.Name)
			_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonPending, "Failed to retrieve Issuer resource %s: %v", issNamespaceName, err)
			return ctrl.Result{}, err
		}
	}

	// Fetch the Certificate resource
	certificate := new(cmapi.Certificate)
	certName := cr.ObjectMeta.Annotations["cert-manager.io/certificate-name"]
	cerNamespaceName := types.NamespacedName{
		Namespace: req.Namespace,
		Name:      certName,
	}
	if err = r.Client.Get(ctx, cerNamespaceName, certificate); err != nil {
		logger.Error(err, "PAWCA failed to retrieve Certificate resource", "namespace", req.Namespace, "name", certName)
		_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonPending, "Failed to retrieve Certificate resource %s: %v", cerNamespaceName, err)
		return ctrl.Result{}, err
	}

	// get status
	requestState := OrderStatusNew
	if cond := apiutil.GetCertificateRequestCondition(cr, cmapi.CertificateRequestConditionReady); cond != nil {
		dbg.Info(fmt.Sprintf("PAWCA     Status.Condition.Type:               %s", string(cond.Type)))
		dbg.Info(fmt.Sprintf("PAWCA     Status.Condition.Status:             %s", string(cond.Status)))
		dbg.Info(fmt.Sprintf("PAWCA     Status.Condition.LastTransitionTime: %s", cond.LastTransitionTime.Time.String()))
		dbg.Info(fmt.Sprintf("PAWCA     Status.Condition.Reason:             %s", cond.Reason))
		dbg.Info(fmt.Sprintf("PAWCA     Status.Condition.Message:            %s", cond.Message))
		if cond.Status == cmmeta.ConditionFalse && cond.Reason == cmapi.CertificateRequestReasonPending {
			messageComponents := strings.Split(cond.Message, " ")
			requestState = messageComponents[0]
		} else {
			requestState = OrderStatusSkip
		}
	}
	dbg.Info(fmt.Sprintf("PAWCA RequestState:      %s", requestState))
	dbg.Info(fmt.Sprintf("PAWCA RequestId:         %s", fmt.Sprintf("%d", requestId)))

	// - NEW or CAAPIERROR
	//   - call CA API
	//     - unreachable or 500
	//       - set state CAAPIERROR / CertificateRequestReasonPending
	//     - status 4xx
	//       - set state FAILED / CertificateRequestReasonFailed
	//     - status 2xx
	//       - set state REQUESTED <order-id> / CertificateRequestReasonPending
	if requestId == -1 {

		requestId, err, shouldRetry := r.CAService.requestCertificateSigning(logger, cr, certificate)
		if err != nil {
			if shouldRetry {
				_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonPending, "%s %v", OrderStatusFailed, err)
				return ctrl.Result{}, err
			} else {
				_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonFailed, "%s %v", OrderStatusFailed, err)
				return ctrl.Result{}, nil
			}
		}
		logger.Info(fmt.Sprintf("PAWCA Signing requested. id: %d", requestId))

		// add the request id as annotation
		cr.ObjectMeta.Annotations[requestIdAnnotationKey] = fmt.Sprintf("%d", requestId)
		err = r.Update(ctx, cr)
		if err != nil {
			_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonPending, "%s %v", OrderStatusFailed, err)
			return ctrl.Result{}, err
		}

		for k := range cr.ObjectMeta.Annotations {
			dbg.Info(fmt.Sprintf("PAWCA     Annotation %s = %s", k, cr.ObjectMeta.Annotations[k]))
		}

		// set to approved
		apiutil.SetCertificateRequestCondition(cr, cmapi.CertificateRequestConditionApproved, cmmeta.ConditionTrue, cmapi.CertificateRequestReasonIssued, "auto-approval")

		_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonPending, "%s %d", OrderStatusRequested, requestId)
		return ctrl.Result{
			Requeue: true,
		}, nil

	} else {
		// - REQUESTED or REQUESTED_CAAPIERROR
		//   - get order-id
		//   - query CA API
		//     - unreachable or 500
		//       - set state REQUESTED_CAAPIERROR <order-id> / CertificateRequestReasonPending
		//     - status 2xx
		//       - cert not yet ready
		//         - set state REQUESTED_PENDING <order-id> / CertificateRequestReasonPending
		//       - cert signing failed
		//         - set state FAILED
		//       - cert done
		//         - update Certificate Request
		//         - set Certificate Request to Ready / CertificateRequestReasonIssued
		//

		certData, caData, err, shouldRetry := r.CAService.getSigningRecord(logger, requestId)
		if err != nil {
			if shouldRetry {
				_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonPending, "%s %v", OrderStatusCaAPIQuereyError, err)
				return ctrl.Result{}, err
			} else {
				_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonFailed, "%s %v", OrderStatusCaAPIQuereyError, err)
				return ctrl.Result{}, nil
			}
		}
		if shouldRetry {
			logger.Info(fmt.Sprintf("PAWCA Signing request with id: %d is still pending", requestId))
			_ = r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonPending, "%s %d", OrderStatusSigningPending, requestId)
			return ctrl.Result{
				Requeue: true,
			}, nil
		}

		cr.Status.Certificate = certData
		cr.Status.CA = caData
		_ = r.setStatus(ctx, cr, cmmeta.ConditionTrue, cmapi.CertificateRequestReasonIssued, "%s %d", OrderStatusDone, requestId)
		logger.Info(fmt.Sprintf("PAWCA Signing with id: %d completed", requestId))
		dbg.Info("PAWCA stop")
		dbg.Info("PAWCA --------------------------------------------------------")

		return ctrl.Result{}, nil
	}

}

// SetupWithManager sets up the controller with the Manager.
func (r *CertificateRequestReconciler) SetupWithManager(mgr ctrl.Manager) error {
	return ctrl.NewControllerManagedBy(mgr).
		For(&cmapi.CertificateRequest{}).
		Complete(r)
}

// requestShouldBeProcessed will return false if the conditions on the request
// mean that it should not be processed. If the request has been denied, it
// will set the request failure time and add a Ready=False condition.
func (r *CertificateRequestReconciler) requestShouldBeProcessed(ctx context.Context, logger logr.Logger, cr *cmapi.CertificateRequest) (bool, error) {
	dbg := logger.V(levelDebug)

	// Ignore CertificateRequest if it is already Ready
	if apiutil.CertificateRequestHasCondition(cr, cmapi.CertificateRequestCondition{
		Type:   cmapi.CertificateRequestConditionReady,
		Status: cmmeta.ConditionTrue,
	}) {
		dbg.Info("PAWCA CertificateRequest is Ready. Ignoring.")
		return false, nil
	}
	// Ignore CertificateRequest if it is already Failed
	if apiutil.CertificateRequestHasCondition(cr, cmapi.CertificateRequestCondition{
		Type:   cmapi.CertificateRequestConditionReady,
		Status: cmmeta.ConditionFalse,
		Reason: cmapi.CertificateRequestReasonFailed,
	}) {
		dbg.Info("PAWCA CertificateRequest is Failed. Ignoring.")
		return false, nil
	}
	// Ignore CertificateRequest if it already has a Denied Ready Reason
	if apiutil.CertificateRequestHasCondition(cr, cmapi.CertificateRequestCondition{
		Type:   cmapi.CertificateRequestConditionReady,
		Status: cmmeta.ConditionFalse,
		Reason: cmapi.CertificateRequestReasonDenied,
	}) {
		dbg.Info("PAWCA CertificateRequest already has a Ready condition with Denied Reason. Ignoring.")
		return false, nil
	}

	// If CertificateRequest has been denied, mark the CertificateRequest as
	// Ready=Denied and set FailureTime if not already.
	if apiutil.CertificateRequestIsDenied(cr) {
		dbg.Info("PAWCA CertificateRequest has been denied. Marking as failed.")

		if cr.Status.FailureTime == nil {
			nowTime := metav1.NewTime(r.Clock.Now())
			cr.Status.FailureTime = &nowTime
		}

		message := "The CertificateRequest was denied by an approval controller"
		return false, r.setStatus(ctx, cr, cmmeta.ConditionFalse, cmapi.CertificateRequestReasonDenied, message)
	}

	// If the certificate data is already set then we skip this request as it
	// has already been completed in the past.
	if len(cr.Status.Certificate) > 0 {
		dbg.Info("PAWCA existing certificate data found in status, skipping already completed CertificateRequest") //nolint:gomnd // TODO: fix when refactoring the logger
		return false, nil
	}

	// we don't support CAs
	if cr.Spec.IsCA {
		dbg.Info("PAWCA PickleAppware certificate does not support online signing of CA certificates")
		return false, nil
	}

	return true, nil
}

func (r *CertificateRequestReconciler) setStatus(ctx context.Context, cr *cmapi.CertificateRequest, status cmmeta.ConditionStatus, reason, message string, args ...interface{}) error {
	completeMessage := fmt.Sprintf(message, args...)
	apiutil.SetCertificateRequestCondition(cr, cmapi.CertificateRequestConditionReady, status, reason, completeMessage)

	// Fire an Event to additionally inform users of the change
	eventType := core.EventTypeNormal
	if status == cmmeta.ConditionFalse {
		eventType = core.EventTypeWarning
	}
	r.Recorder.Event(cr, eventType, reason, completeMessage)

	return r.Status().Update(ctx, cr)
}

// Helper functions to check and remove string from a slice of strings.
func containsString(slice []string, s string) bool {
	for _, item := range slice {
		if item == s {
			return true
		}
	}
	return false
}

func removeString(slice []string, s string) (result []string) {
	for _, item := range slice {
		if item == s {
			continue
		}
		result = append(result, item)
	}
	return
}
