package controllers

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"

	"github.com/go-logr/logr"
	cmapi "github.com/jetstack/cert-manager/pkg/apis/certmanager/v1"
)

type PAWCAService struct{}

// request the CSR to be signed. Return the request-id, and error or nil and if the request should be retried in case of error
func (r *PAWCAService) requestCertificateSigning(logger logr.Logger, cr *cmapi.CertificateRequest, c *cmapi.Certificate) (int, error, bool) {
	dbg := logger.V(levelDebug)
	// prepare SAN parameter
	var sanList []string
	for _, entry := range c.Spec.DNSNames {
		sanList = append(sanList, fmt.Sprintf("DNS:%s", entry))
	}
	for _, entry := range c.Spec.IPAddresses {
		sanList = append(sanList, fmt.Sprintf("IP:%s", entry))
	}
	for _, entry := range c.Spec.URIs {
		sanList = append(sanList, fmt.Sprintf("URI:%s", entry))
	}
	for _, entry := range c.Spec.EmailAddresses {
		sanList = append(sanList, fmt.Sprintf("email:%s", entry))
	}

	// prepare key usage
	keyUsageMap := map[string]string{
		"digital signature": "digitalSignature",
		"signing":           "nonRepudiation",
		"key encipherment":  "keyEncipherment",
		"data encipherment": "dataEncipherment",
		"key agreement":     "keyAgreement",
		"cert sign":         "keyCertSign",
		"crl sign":          "cRLSign",
		"encipher only":     "encipherOnly",
		"decipher only":     "decipherOnly",
	}
	extendedKeyUsageMap := map[string]string{
		"server auth":      "serverAuth",
		"client auth":      "clientAuth",
		"code signing":     "codeSigning",
		"email protection": "emailProtection",
		"ocsp signing":     "OCSPSigning",
	}
	var keyUsageList []string
	var extendedKeyUsageList []string

	for _, keyUsage := range cr.Spec.Usages {
		dbg.Info(fmt.Sprintf("keyUsage  %s", keyUsage))
		if tmpValue, ok := keyUsageMap[string(keyUsage)]; ok {
			keyUsageList = append(keyUsageList, tmpValue)
		} else if tmpValue, ok := extendedKeyUsageMap[string(keyUsage)]; ok {
			extendedKeyUsageList = append(extendedKeyUsageList, tmpValue)
		} else {
			supportedKeys := make([]string, 0, len(keyUsageMap)+len(extendedKeyUsageMap))
			for k := range keyUsageMap {
				supportedKeys = append(supportedKeys, k)
			}
			for k := range extendedKeyUsageMap {
				supportedKeys = append(supportedKeys, k)
			}
			return -1, fmt.Errorf("Unsupported key usage %s. Supported usages are %s", keyUsage, strings.Join(supportedKeys[:], ", ")), false
		}
	}

	// echo for common name
	if c.Spec.CommonName == "" {
		return -1, fmt.Errorf("CommonName missing. CommonName is mandatory parameter"), false
	}

	// create request structure
	type PAWCASigningRequest struct {
		Name             string `json:"name,omitempty"`
		Csr              string `json:"csr,omitempty"`
		Subject          string `json:"subject,omitempty"`
		San              string `json:"san,omitempty"`
		KeyUsage         string `json:"keyUsage,omitempty"`
		ExtendedKeyUsage string `json:"extendedKeyUsage,omitempty"`
	}

	// create request
	caSigingRequest := PAWCASigningRequest{
		Name:             fmt.Sprintf("%s.%s", c.ObjectMeta.GetNamespace(), c.ObjectMeta.GetName()),
		Csr:              string(cr.Spec.Request),
		Subject:          c.Spec.CommonName,
		San:              strings.Join(sanList[:], ", "),
		KeyUsage:         strings.Join(keyUsageList[:], ", "),
		ExtendedKeyUsage: strings.Join(extendedKeyUsageList[:], ", "),
	}

	// add CSR
	caSigingRequestString, _ := json.Marshal(caSigingRequest)

	// perfrom POST request
	dbg.Info("PAWCA POST:         " + string(caSigingRequestString))
	client := &http.Client{}
	crReader := bytes.NewReader(caSigingRequestString)
	restReq, _ := http.NewRequest("POST", "http://ca.mycloud.net/api/v1/ca/request", crReader)
	restReq.Header.Add("Content-Type", "application/json")
	restReq.Header.Add("accept", "application/json")
	resp, err := client.Do(restReq)
	if err != nil {
		return -1, err, true
	}

	// process response
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	dbg.Info("PAWCA POST: Response Body         " + string(body))
	if resp.StatusCode >= 400 && resp.StatusCode < 500 { // in case of a bad request, fail and don't retry
		return -1, fmt.Errorf("%s %s", resp.Status, body), false
	} else if resp.StatusCode == 201 { // in case of success proecced the response
		trimedBody := strings.TrimSpace(string(body))
		requestId, err := strconv.Atoi(trimedBody)
		if err != nil { // if we cannot parse the response, the nfail and don't retry
			return -1, fmt.Errorf("Failed parsing \"%s\"", string(body)), false
		}
		return requestId, nil, false
	} else { // in case of another error, fail and retry
		return -1, fmt.Errorf("Unknown Error: %s %s", resp.Status, body), true
	}
}

// get the signed certificate. Return the certificate, ca and error or nil and if the request should be retried in case of error
func (r *PAWCAService) getSigningRecord(logger logr.Logger, requestId int) ([]byte, []byte, error, bool) {
	dbg := logger.V(levelDebug)
	// get record
	url := fmt.Sprintf("http://ca.mycloud.net/api/v1/ca/request/%d", requestId)
	dbg.Info("PAWCA GET:         " + url)
	resp, err := http.Get(url)
	if err != nil {
		return []byte(""), []byte(""), err, true
	}
	if resp.StatusCode == 200 {
		type PAWCASigningResponse struct {
			Name          string `json:"name,omitempty"`
			Status        string `json:"status,omitempty"`
			Subject       string `json:"subject,omitempty"`
			San           string `json:"san,omitempty"`
			Csr           string `json:"csr,omitempty"`
			Certificate   string `json:"certificate,omitempty"`
			CACertificate string `json:"cacertificate,omitempty"`
			Expiry        string `json:"expiry,omitempty"`
			RequestId     string `json:"requestId,omitempty"`
			Error         string `json:"error,omitempty"`
		}

		var pawResponse PAWCASigningResponse
		err = json.NewDecoder(resp.Body).Decode(&pawResponse)
		if err != nil {
			return []byte(""), []byte(""), err, false
		}
		dbg.Info("PAWCA GET: Response Status         " + pawResponse.Status)

		if pawResponse.Status == "PROCESSED" {
			return []byte(pawResponse.Certificate), []byte(pawResponse.CACertificate), nil, false
		} else if pawResponse.Status == "SCHEDULED" {
			return []byte(""), []byte(""), nil, true
		} else if pawResponse.Status == "FAILED" {
			body, _ := json.Marshal(pawResponse)
			return []byte(""), []byte(""), fmt.Errorf("Signing failed: %s", body), false
		} else {
			body, _ := json.Marshal(pawResponse)
			return []byte(""), []byte(""), fmt.Errorf("Signing failed with unknown error: %s", body), true
		}
	} else {
		body, err := io.ReadAll(resp.Body)
		return []byte(""), []byte(""), fmt.Errorf("Signing call failed: request-id: %d return code: %s response: %s %v", requestId, resp.Status, body, err), true
	}
}

// get the signed certificate. Return the certificate, ca and error or nil and if the request should be retried in case of error
func (r *PAWCAService) deleteSigningRecord(logger logr.Logger, requestId int) error {
	dbg := logger.V(levelDebug)
	// delete record
	url := fmt.Sprintf("http://ca.mycloud.net/api/v1/ca/request/%d", requestId)
	dbg.Info("PAWCA DELETE:         " + url)
	client := &http.Client{}
	restReq, _ := http.NewRequest("DELETE", url, nil)
	resp, err := client.Do(restReq)
	if err != nil {
		return err
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	if resp.StatusCode == 204 {
		logger.Info("PAWCA Signing Record deleted successfully")
	} else {
		dbg.Info(fmt.Sprintf("PAWCA Delete response: %s %s", resp.Status, string(body)))
	}
	return nil
}
